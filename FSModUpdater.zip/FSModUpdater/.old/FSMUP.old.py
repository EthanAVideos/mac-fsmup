#All Right EthanA Videos, Developer Of This Software.
#Date Made: 9/10/23
#Date Last Updated: 9/27/23
#Version: 1.0.0.1 Testing Version (DEPRECATED)

#You are not to open / change this file without written consent from EthanA Videos.

import tkinter as tk
from tkinter import filedialog
import os
import zipfile
import xml.etree.ElementTree as ET
import shutil

# Function to update mods
def update_mods():
    # Get the entered descVersion number
    desc_version = entry.get()

    # Get a list of zip files in the "update" folder
    update_folder = "update"
    updated_folder = "updated"
    
    zip_files = [f for f in os.listdir(update_folder) if f.endswith(".zip")]

    for zip_file in zip_files:
        # Construct the paths
        mod_zip_path = os.path.join(update_folder, zip_file)
        mod_folder = os.path.splitext(zip_file)[0]
        mod_folder_path = os.path.join(update_folder, mod_folder)
        updated_mod_zip_path = os.path.join(updated_folder, zip_file)

        # Extract the mod folder
        with zipfile.ZipFile(mod_zip_path, 'r') as zip_ref:
            zip_ref.extractall(mod_folder_path)

        # Parse the modDesc.xml file and update the descVersion
        xml_file_path = os.path.join(mod_folder_path, 'modDesc.xml')
        if os.path.isfile(xml_file_path):
            tree = ET.parse(xml_file_path)
            root = tree.getroot()
            root.set('descVersion', desc_version)

            # Write the updated XML
            tree.write(xml_file_path, encoding="utf-8", xml_declaration=True)

        # Create a new zip file with the updated mod folder
        with zipfile.ZipFile(updated_mod_zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
            for foldername, subfolders, filenames in os.walk(mod_folder_path):
                for filename in filenames:
                    file_path = os.path.join(foldername, filename)
                    arcname = os.path.relpath(file_path, mod_folder_path)
                    zip_ref.write(file_path, arcname)

        # Clear the temporary mod folder (remove all files and subfolders)
        clear_mod_folder(mod_folder_path)

        # Remove the temporary mod folder
        os.rmdir(mod_folder_path)

    result_label.config(text="Mods Updated!")

def clear_mod_folder(folder_path):
    # Clear all files and subfolders within the folder
    for root_folder, _, files in os.walk(folder_path):
        for file in files:
            os.remove(os.path.join(root_folder, file))
        for subfolder in os.listdir(root_folder):
            subfolder_path = os.path.join(root_folder, subfolder)
            if os.path.isdir(subfolder_path):
                shutil.rmtree(subfolder_path)

# Create the main window
root = tk.Tk()
root.title("(EAV) FS Mod Updater (v1.0.0.1) - (DEPRECATED)")

# Set the initial window size (width x height)
window_width = 900
window_height = 600
root.geometry(f"{window_width}x{window_height}")

# Create and configure the label in the right bottom corner
bottom_right_label = tk.Label(root, text="All Right EthanA Videos© 2020 - 2023")
bottom_right_label.place(x=330, y=200)  # Adjust the coordinates as needed

#Create label, apps version
version_label = tk.Label(root, text="Version: 1.0.0.1 Testing (DEPRECATED)")
version_label.place(x=10, y=30)  # Adjust the coordinates as needed

# Create and configure the label in the left top corner with a hyperlink-like cursor
top_left_label = tk.Label(
    root, text="Developed By EthanA Videos", cursor="hand2", foreground="blue")
top_left_label.place(x=10, y=10)  # Adjust the coordinates as needed

# Bind a function to open the hyperlink when the label is clicked
def open_website(event):
    import webbrowser
    webbrowser.open("http://eav.us.to/assets")

top_left_label.bind("<Button-1>", open_website)

# Create and configure the label at the bottom center
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

# Create and configure the label
label = tk.Label(root, text="Place mods in 'update/'. Once updated, they can be found in 'updated/'.")
label.pack(pady=10)

# Create and configure the entry field
entry = tk.Entry(root)
entry.pack(pady=10)

# Create and configure the update button
update_button = tk.Button(root, text="Update Mods", command=update_mods)
update_button.pack(pady=10)

# Start the main loop
root.mainloop()

