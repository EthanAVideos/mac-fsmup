#!/bin/bash
# You are not to open, view, change, share this file this is against are license.
# Author: Ethan
# Owner: EthanA Videos
# Date Of Creation: 11-04-23
# Last Updated: 11-07-23
# Description: This shell script is to ran from terminal it is made so you can do everything from menu's.

echo ""
echo ""
echo "Disclaimer: We can not be held liable for any damage or issues for having this or running this script / software please read are license agreement."
echo ""
echo ""

# Change the working directory to the directory of this script
cd "$(dirname "$0")"

# Function to display the menu
display_menu() {
 echo ""
  echo ""
  echo ""
  echo "Main Menu Options:"
  echo "1. Run Mod Updater"
  echo "2. Read License Agreement"
  echo "3. Information"
  echo "4. Development"
  echo "0. Exit"
   echo ""
  echo ""
  echo ""
}

# Main menu loop
while true; do
  display_menu
  read -p "Enter your choice: " choice
  case $choice in
    1)
      # Code to run FSMUP
       echo ""
  echo ""
  echo ""
      echo "Running FSMUP..."
      sleep 1
        echo ""
  echo ""
      sh run.sh
       echo ""
  echo ""
  echo ""
      ;;
    2)
      # Code to display LAM
       echo ""
  echo ""
  echo ""
      echo "Displaying License Agreement..."
      sleep 1
        echo ""
  echo ""
      cat ../License.md
       echo ""
  echo ""
  echo ""
      ;;
    3)
    	# Code to display INFO
    	  echo ""
  echo ""
  echo "Displaying Information..."
  sleep 1
    echo ""
  echo ""
  echo ""
echo ""
echo ""
echo ""
echo "====================================================="
echo "Program Made: 9/10/23"
echo "Last Updated: 11/07/23"
echo "Version: 2.0.0.4"
echo "Linux Version"

echo ""

echo "EthanA Videos developed this software & owns it."
echo "All Right EthanA Videos© 2020 - 2023"
echo "http://eav.us.to/assets"
echo "====================================================="

echo ""

#helpful documents
echo "Need any help view document/"
echo ".development/"
echo "python3 FSMUP.py"
echo "http://eav.us.to/assets"
echo "====================================================="

echo ""
echo ""
echo ""
echo ""
;;
4)
  # Code to display DEVM
  # Function to display the menu
  display_development_menu() {
   echo ""
   echo "Displaying Development Menu..."
   sleep 1
  echo ""
  echo ""
    echo "Development Menu Options:"
    echo "1. Show Log"
    echo "2. Run Old Version of FSMUP"
    echo "Note: Clearing the log file breaks our license agreement!"
    echo "3. Clear Log"
    echo "0. Exit"
     echo ""
  echo ""
  echo ""
  }

  # Main menu loop for the development menu
  while true; do
    display_development_menu
    read -p "Enter your choice: " choice
    case $choice in
      1)
        # Code to display log
         echo ""
  echo ""
  echo ""
  echo "Displaying Log..."
  sleep 1
    echo ""
  echo ""
        cat .development/log.txt
        ;;
      2)
        # Code to run FSMUP *old
         echo ""
  echo ""
  echo ""
        echo "Running FSMUP (DEPRECATED)..."
        sleep 1
          echo ""
  echo ""
        echo "Note: Running an older version of FSMUP may cause issues / not work and is against our license agreement."
        sleep 1
        echo "Running in 2"
        sleep 2
        python3 .old/FSMUP.old.py
         echo ""
  echo ""
  echo ""
        ;;
      3)
       echo ""
  echo ""
  echo ""
  echo "Clearing Log..."
  sleep 1
    echo ""
  echo ""
        # Code to clear the log file
        log_file=".development/log.txt"
        if [ -f "$log_file" ]; then
          > "$log_file"  # Clear the contents of the file
          log_message="*! Log Cleared on $(date) !*"
          echo "$log_message" >> "$log_file"
          echo "Log cleared and updated with the current date."
        else
          echo "File not found: $log_file"
        fi
         echo ""
  echo ""
  echo ""
        ;;
      0)
       echo ""
  echo ""
  echo ""
        echo "Exiting the development menu."
        sleep 1
        break  # Exit the development menu loop
         echo ""
  echo ""
  echo ""
        ;;
      *)
       echo ""
  echo ""
  echo ""
        echo "Invalid choice. Please select a valid option."
         echo ""
  echo ""
  echo ""
        ;;
    esac
  done
      ;;
    0)
     echo ""
  echo ""
  echo ""
      echo "Exiting the program."
      sleep 1
      exit 0
       echo ""
  echo ""
  echo ""
      ;;
    *)
     echo ""
  echo ""
  echo ""
      echo "Invalid choice. Please select a valid option."
       echo ""
  echo ""
  echo ""
      ;;
  esac
done


