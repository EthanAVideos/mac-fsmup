#!/bin/bash

# Change the working directory to the directory of this script
cd "$(dirname "$0")"

# Run the Python script
python3 ./FSMUP.py

#Comments
#NOTE: The below was used for version older then v2.0.0.3 as 2.0.0.4 uses cmd.sh menu & the info text is no longer needed. 
<<EOF
echo ""
echo ""
echo ""
echo ""
echo "====================================================="
echo "Program Made: 9/10/23"
echo "Last Updated: 9/27/23"
echo "Version: 2.0.0.2"
echo "Linux Version"

echo ""

echo "EthanA Videos developed this software & owns it."
echo "All Right EthanA Videos© 2020 - 2023"
echo "http://eav.us.to/assets"
echo "====================================================="

echo ""

#helpful documents
echo "Need any help view document/"
echo ".development/"
echo "python3 FSMUP.py"
echo "http://eav.us.to/assets"
echo "====================================================="

echo ""
echo ""
echo ""
echo ""

EOF

#Note to dev: This file is not as needed due to cmd.sh ,  this file cmd.sh will soon become run.sh